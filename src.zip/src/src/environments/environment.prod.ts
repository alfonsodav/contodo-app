export const environment = {
  production: true,
  webClientId: '1075847961326-7dpusk7uoa3g9h7f1bltv1s362e4ovks.apps.googleusercontent.com',
  //api: 'http://38.17.54.101/contodo_API/'
  api: 'http://208.51.60.82/contodo_API/'
};
export const firebaseConfig = {
  apiKey: 'AIzaSyCS1TNBYP76BC-T5YUL4brRgscqRV4twsM',
  authDomain: 'con-todo-a7dcb.firebaseapp.com',
  projectId: 'con-todo-a7dcb',
  storageBucket: 'con-todo-a7dcb.appspot.com',
  messagingSenderId: '1075847961326',
  appId: '1:1075847961326:android:205bf1d4de708c6ab271ff'
};
